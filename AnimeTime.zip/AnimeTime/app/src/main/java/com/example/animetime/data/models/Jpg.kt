package com.example.animetime.data.models

data class Jpg(
    val image_url: String
) {
}
package com.example.animetime.data.models

data class Images(
    val jpg: Jpg
) {

}
package com.example.animetime.utils

class Constants {
    companion object {
        const val BASE_URL = "https://api.jikan.moe/v4/"



    }
}
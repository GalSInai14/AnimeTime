package com.example.animetime.data.models

data class AllAnimes(
    val data: ArrayList<Anime>
) {
}